import java.util.ArrayList;
import java.util.Scanner;
import java.io.FileReader;
import java.time.LocalDate;

public class Libros {
  private String titulo;
  private String autor;
  private double ISBN;
  private String categoria;
  private boolean disponibilidad;
  private int copias;
  private LocalDate fecha_prestado;
  private LocalDate fecha_devolucion;
  private ArrayList<Libros> catal_libros = new ArrayList<Libros>();
  private ArrayList<Libros> libros_dispo = new ArrayList<Libros>();
  private ArrayList<Libros> libros_prestados = new ArrayList<Libros>();
  private ArrayList<Usuarios> usuarios_registrados = new ArrayList<Usuarios>();

  public Libros(){
    
  }
  public Libros(String titulo, String autor, double ISBN, String categoria, boolean disponibilidad){
    this.titulo = titulo;
    this.copias = 0;
    this.autor = autor;
    this.ISBN = ISBN;
    this.categoria = categoria;
    this.disponibilidad = disponibilidad;
  }
  public void set_titulo(String titulo){
    this.titulo = titulo;
  }
  public String get_titulo(){
    return titulo;
  }
  public void set_autor(String autor){
    this.autor = autor;
  }
  public String get_autor(){
    return autor;
  }
  public void set_ISBN(double ISBN){
    this.ISBN = ISBN;
  }
  public double get_ISBN(){
    return ISBN;
  }
  public void set_disponibilidad(boolean disponibilidad){
    this.disponibilidad = disponibilidad;
  }
  public boolean get_disponibilidad(){
    return disponibilidad;
  }
  public void set_categoria(String categoria){
    this.categoria = categoria;
  }
  public String get_categoria(){
    return categoria;
  }
  public void set_fecha_prestado(int año, int mes, int dia){
    this.fecha_prestado = LocalDate.of(año, mes, dia);
  }
  public LocalDate get_fechaprestado(){
    return fecha_prestado;
  }
  public int get_año(){
    return fecha_prestado.getYear();
  }
  public int get_mes(){
    return fecha_prestado.getMonthValue();
  }
  public int get_dia(){
    return fecha_prestado.getDayOfMonth();
  }
  public void set_fecha_devolucion(int año, int mes, int dia){
    this.fecha_devolucion = LocalDate.of(año, mes, dia);
  }
  public LocalDate get_fechadevolucion(){
    return fecha_devolucion;
  }
  public void set_copias(int copias){
    this.copias = copias;
  }
  public int get_copias(){
    return copias;
  }
  public void mostrar_usuariosregistrados(){
    System.out.println("Los usuarios registrados en el sistema son: ");
    for(int i = 0; i < usuarios_registrados.size(); i++){
      System.out.println("Nombre: " + usuarios_registrados.get(i).get_nombre());
      System.out.println("Identificación: " + usuarios_registrados.get(i).get_identificacion());
      System.out.println("Numero de libros prestados: " + usuarios_registrados.get(i).get_librospres());
      System.out.println();
    }
  }
  public void mostrar_librospres(){
    System.out.println("Los libros que tenemos prestados son: ");
    for (int i = 0; i < catal_libros.size(); i++){
      System.out.println("El titulo es: " + libros_prestados.get(i).get_titulo());
      System.out.println("El nombre del autor es: " + libros_prestados.get(i).get_autor());
      System.out.println("El ISBN es: " + libros_prestados.get(i).get_ISBN());
      System.out.println("La categoría es: " + libros_prestados.get(i).get_categoria());
      System.out.println("La disponibilidad es: " + libros_prestados.get(i).get_disponibilidad());
      System.out.println();
    }
  }
  public void mostrar_librosdisp(){
    System.out.println("Los libros que tenemos disponibles son: ");
    for (int i = 0; i < catal_libros.size(); i++){
      System.out.println("El titulo es: " + libros_dispo.get(i).get_titulo());
      System.out.println("El nombre del autor es: " + libros_dispo.get(i).get_autor());
      System.out.println("El ISBN es: " + libros_dispo.get(i).get_ISBN());
      System.out.println("La categoría es: " + libros_dispo.get(i).get_categoria());
      System.out.println("La disponibilidad es: " + libros_dispo.get(i).get_disponibilidad());
      System.out.println();
    }
  }
  public void get_catalogo(){
    FileReader fr = null;
    Scanner input = null;
    
    try {
      fr = new FileReader("src/main/java/libros.text");
      input = new Scanner(fr);
      boolean disp = true;
      String libro[] = input.nextLine().split(",");
      String libro1[] = input.nextLine().split(",");
      String libro2[] = input.nextLine().split(",");
      String libro3[] = input.nextLine().split(",");
      String libro4[] = input.nextLine().split(",");
      String libro5[] = input.nextLine().split(",");
      String libro6[] = input.nextLine().split(",");
      String libro7[] = input.nextLine().split(",");
      String libro8[] = input.nextLine().split(",");
      String libro9[] = input.nextLine().split(",");
      Libros libro_1 = new Libros(libro[0], libro[1], Integer.parseInt(libro[3].replace("-", "")), libro[2], disp);
      Libros libro_2 = new Libros(libro1[0], libro1[1], Integer.parseInt(libro1[3].replace("-", "")), libro1[2], disp);
      Libros libro_3 = new Libros(libro2[0], libro2[1], Integer.parseInt(libro2[3].replace("-", "")), libro2[2], disp);
      Libros libro_4 = new Libros(libro3[0], libro3[1], Integer.parseInt(libro3[3].replace("-", "")), libro3[2], disp);
      Libros libro_5 = new Libros(libro4[0], libro4[1], Integer.parseInt(libro4[3].replace("-", "")), libro4[2], disp);
      Libros libro_6 = new Libros(libro5[0], libro5[1], Integer.parseInt(libro5[3].replace("-", "")), libro5[2], disp);
      Libros libro_7 = new Libros(libro6[0], libro6[1], Integer.parseInt(libro6[3].replace("-", "")), libro6[2], disp);
      Libros libro_8 = new Libros(libro7[0], libro7[1], Integer.parseInt(libro7[3].replace("-", "")), libro7[2], disp);
      Libros libro_9 = new Libros(libro8[0], libro8[1], Integer.parseInt(libro8[3].replace("-", "")), libro8[2], disp);
      Libros libro_10 = new Libros(libro9[0], libro9[1], Integer.parseInt(libro9[3].replace("-", "")), libro9[2], disp);
      catal_libros.add(libro_1);
      catal_libros.add(libro_2);
      catal_libros.add(libro_3);
      catal_libros.add(libro_4);
      catal_libros.add(libro_5);
      catal_libros.add(libro_6);
      catal_libros.add(libro_7);
      catal_libros.add(libro_8);
      catal_libros.add(libro_9);
      catal_libros.add(libro_10);
      for (int i = 0; i < catal_libros.size(); i++){
        for (int j = 1; j < catal_libros.size(); j++){
        if(catal_libros.get(i).get_titulo().equalsIgnoreCase(catal_libros.get(j).get_titulo())){
           catal_libros.remove(i);
        }
      }
    }
      for (int i = 0; i < catal_libros.size(); i++){
        if(catal_libros.get(i).get_disponibilidad() == true){
          libros_dispo.add(catal_libros.get(i));
        }
        else {
          libros_prestados.add(catal_libros.get(i));
        }
      }
    } catch (Exception e){
      System.out.println("Error leyendo el archivo");
    }
    System.out.println("El catálogo de libro que disponemos es: ");
    for (int i = 0; i < catal_libros.size(); i++){
      System.out.println("El titulo es: " + catal_libros.get(i).get_titulo());
      System.out.println("El nombre del autor es: " + catal_libros.get(i).get_autor());
      System.out.println("El ISBN es: " + catal_libros.get(i).get_ISBN());
      System.out.println("La categoría es: " + catal_libros.get(i).get_categoria());
      System.out.println("La disponibilidad es: " + catal_libros.get(i).get_disponibilidad());
      System.out.println("Las copias que tienen son: " + catal_libros.get(i).get_copias());
      System.out.println();
    }
  }
  public void agregar_libros(){
    Scanner input = new Scanner(System.in);
    System.out.println("Ingrese el titulo del libro que desea agregar: ");
    String titulo_nuev = input.nextLine();
    System.out.println("Ingrese el nombre del autor del libro que desea agregar: ");
    String autor_nuev = input.nextLine();
    System.out.println("Ingrese el ISBN del libro que desea agregar (Sin caracteres especiales, solo numeros): ");
    double ISBN = input.nextDouble();
    System.out.println("Ingrese la categoría del libro que desea agregar");
    String categoria = input.nextLine();
    boolean dispo = true;
    Libros libro = new Libros(titulo_nuev, autor_nuev, ISBN, categoria, dispo);
    boolean nuevo = false;
    for (int i = 0; i < catal_libros.size(); i++){
      String titulo = catal_libros.get(i).get_titulo();
      if(!libro.get_titulo().equalsIgnoreCase(titulo)){
        catal_libros.add(libro);
        libros_dispo.add(libro);
        System.out.println("El libro ha sido agregado con éxito");
        nuevo = true;
      }
    }
    if (nuevo == false){
      libros_dispo.add(libro);
      libro.copias++;
      System.out.println("El libro ya se encuentra en nuestro catálogo, por lo tanto hay " + libro.get_copias() + " ejemplares del mismo");
    }
  }
  public void eliminar_libros(){
    Scanner input = new Scanner(System.in);
    System.out.println("Ingrese el titulo del libro que desea eliminar: ");
    String titulo_nuev = input.nextLine();
    boolean encontrado = false;
    for (int i = 0; i < catal_libros.size(); i++){
      String titulo = catal_libros.get(i).get_titulo();
      if(titulo_nuev.equalsIgnoreCase(titulo)){
        catal_libros.remove(i);
        encontrado = true;
        if(titulo_nuev.equalsIgnoreCase(libros_dispo.get(i).get_titulo())){
          libros_dispo.remove(i);
        }
        else if (titulo_nuev.equalsIgnoreCase(libros_prestados.get(i).get_titulo())){
          libros_prestados.remove(i);
        }
        System.out.println("El libro ha sido eliminado con éxito");
      }
    }
    if (encontrado == false){
      System.out.println("No contamos con ese libro. Intente de nuevo");
    }
  }
  
  public void prestar_libros(){
    Scanner input = new Scanner(System.in);
    System.out.println("Ingrese su nombre: ");
    String nombre = input.nextLine();
    System.out.println("Ingrese su numero de identificación: ");
    double id = input.nextDouble();
    boolean usuario_encontrado = false;
    for(int j = 0; j < usuarios_registrados.size(); j++){
      if(usuarios_registrados.get(j).get_nombre().equalsIgnoreCase(nombre) && usuarios_registrados.get(j).get_identificacion() == id){
        System.out.println("El usuario se encuentra registrado en el sistema y tiene: " + usuarios_registrados.get(j).get_librospres() + " libros prestados");
        if (usuarios_registrados.get(j).get_multa() > 0){
          System.out.println("El usuario no puede prestar libros porque tiene una multa pendiente por pagar debido a tardía devolución de libros prestados");
          break;
        }
        else if(usuarios_registrados.get(j).get_multa() == 0){
        usuario_encontrado = true;
        boolean encontrado = false;
        while(encontrado == false){
        mostrar_librosdisp();
        System.out.println("Ingrese el titulo del libro que desea prestar: ");
        String titulo_nuev = input.nextLine();
          if(titulo_nuev.equalsIgnoreCase("Salir")){
            break;
          }
        for (int i = 0; i < libros_dispo.size(); i++){
          String titulo = libros_dispo.get(i).get_titulo();
          if(titulo_nuev.equalsIgnoreCase(titulo)){
            System.out.print("El libro se encuentra disponible para ser prestado. ¿Deseas prestarlo?  (Selecciona Sí o No)");
            String prestar = input.nextLine();
            if (prestar.equalsIgnoreCase("Sí")){
              encontrado = true;
              usuarios_registrados.get(j).libros_prestados++;
              System.out.println("Ingresa el año en que se realizó la prestación del libro");
              int año = input.nextInt();
              System.out.println("Ingresa el mes en que se realizó la prestación del libro");
              int mes = input.nextInt();
              System.out.println("Ingresa el dia en que se realizó la prestación del libro");
              int dia = input.nextInt();
              Libros libro = new Libros(libros_dispo.get(i).get_titulo(), libros_dispo.get(i).get_autor(), libros_dispo.get(i).get_ISBN(), libros_dispo.get(i).get_categoria(), true);
              libro.set_fecha_prestado(año, mes, dia);
              System.out.println("El libro se ha prestado el dia " + dia + " del mes " + mes + " del año " + año);
              System.out.println("El libro se ha prestado con éxito");
              libro.copias--;
              System.out.println("Quedan: " + libro.get_copias() + " copias del libro prestado");
              libros_dispo.remove(i);
              libros_prestados.add(libros_dispo.get(i));
              libros_dispo.get(i).set_disponibilidad(false);
              System.out.println("Tienes 30 días hábiles desde hoy para hacer la devolución o renovación del libro");
              System.out.println("Los libros prestados por el usuario con nombre " + usuarios_registrados.get(j).get_nombre() + " y numero de identificación " + usuarios_registrados.get(j).get_identificacion() + " son: " + usuarios_registrados.get(j).get_librospres());
              break;
            }
            else if (prestar.equalsIgnoreCase("No")) {
              encontrado = true;
              break;
            }
            else {
              System.out.println("Error. Ingrese una opción válida");
            }
            }
          }
          if (encontrado == true) {
            break;
          }
        }
        if (encontrado == false){
          System.out.println("El libro no se encuentra disponible. Intente con otro título");
        }
      }
        System.out.println("Muchas gracias por confiar en nuestros servicios");
        break;
      }
    }
    
    if(usuario_encontrado == false){
    Usuarios usuario1 = new Usuarios(nombre, id);
    usuarios_registrados.add(usuario1);
      boolean encontrado = false;
        while(encontrado == false){
        mostrar_librosdisp();
        System.out.println("Ingrese el titulo del libro que desea prestar: ");
        String titulo_nuev = input.nextLine();
          if(titulo_nuev.equalsIgnoreCase("Salir")){
            break;
          }
        for (int i = 0; i < libros_dispo.size(); i++){
          String titulo = libros_dispo.get(i).get_titulo();
          if(titulo_nuev.equalsIgnoreCase(titulo)){
            System.out.print("El libro se encuentra disponible para ser prestado. ¿Deseas prestarlo?  (Selecciona Sí o No)");
            String prestar = input.nextLine();
            if (prestar.equalsIgnoreCase("Sí")){
              encontrado = true;
              usuario1.libros_prestados++;
              System.out.println("Ingresa el año en que se realizó la prestación del libro");
              int año = input.nextInt();
              System.out.println("Ingresa el mes en que se realizó la prestación del libro");
              int mes = input.nextInt();
              System.out.println("Ingresa el dia en que se realizó la prestación del libro");
              int dia = input.nextInt();
              Libros libro = new Libros(libros_dispo.get(i).get_titulo(), libros_dispo.get(i).get_autor(), libros_dispo.get(i).get_ISBN(), libros_dispo.get(i).get_categoria(), true);
              libro.set_fecha_prestado(año, mes, dia);
              System.out.println("El libro se ha prestado el dia " + dia + " del mes " + mes + " del año " + año);
              System.out.println("El libro se ha prestado con éxito");
              libro.copias--;
              System.out.println("Quedan: " + libro.get_copias() + " copias del libro prestado");
              libros_dispo.remove(i);
              libros_prestados.add(libros_dispo.get(i));
              libros_dispo.get(i).set_disponibilidad(false);
              System.out.println("Tienes 30 días hábiles desde hoy para hacer la devolución o renovación del libro");
              System.out.println("Los libros prestados por el usuario con nombre " + usuario1.get_nombre() + " y numero de identificación " + usuario1.get_identificacion() + " son: " + usuario1.get_librospres());
              break;
            }
            else if (prestar.equalsIgnoreCase("No")) {
              encontrado = true;
              break;
            }
            else {
              System.out.println("Error. Ingrese una opción válida");
            }
            }
          }
          if (encontrado == true) {
            break;
          }
        if (encontrado == false){
          System.out.println("El libro no se encuentra disponible. Intente con otro título");
        }
      }
        System.out.println("Muchas gracias por confiar en nuestros servicios");
      }
  }
    
  public void devolver_libros(){
    Scanner input = new Scanner(System.in);
    System.out.println("Ingrese su nombre: ");
    String nombre = input.nextLine();
    System.out.println("Ingrese su numero de identificación: ");
    double id = input.nextDouble();
    System.out.println("Ingrese el titulo del libro que desea devolver: ");
    String titulo_nuev = input.nextLine();
    boolean libro_encontrado = false;
    boolean usuario_encontrado = false;
    for(int j = 0; j < usuarios_registrados.size(); j++){
       if(usuarios_registrados.get(j).get_nombre().equalsIgnoreCase(nombre) && usuarios_registrados.get(j).get_identificacion() == id){
      for (int i = 0; i < libros_prestados.size(); i++){
        if(titulo_nuev.equalsIgnoreCase(libros_prestados.get(i).get_titulo())){
        usuario_encontrado = true;
        libro_encontrado = true;
        System.out.println("Ingresa el año en que se realizó la devolución del libro");
        int año = input.nextInt();
        System.out.println("Ingresa el mes en que se realizó la devolución del libro");
        int mes = input.nextInt();
        System.out.println("Ingresa el dia en que se realizó la devolución del libro");
        int dia = input.nextInt();
        libros_prestados.get(i).set_fecha_devolucion(año, mes, dia);
        if(mes == libros_prestados.get(i).get_mes()){
          int fecha_limite = dia - libros_prestados.get(i).get_dia();
          System.out.println("El libro se devolvió en el tiempo establecido: " + fecha_limite + " días");
        }
        if(mes > libros_prestados.get(i).get_mes()){
          if ((mes - libros_prestados.get(i).get_mes()) == 1){
          int fecha_limite = ((30 - libros_prestados.get(i).get_dia() + dia) - 30);
          usuarios_registrados.get(j).set_multa(fecha_limite * 10000);
          usuarios_registrados.get(j).set_cantmultas();
           System.out.println("El libro fue devuelto con retraso. Excedió el límite máximo de días prestados. Se le cobrará una multa de $10.000 por cada día de retraso. El valor total de su multa fue: " + usuarios_registrados.get(j).get_multa());
          }
            // Asumimos que todos los meses son de 30 días
          else if ((mes - libros_prestados.get(i).get_mes()) > 1){
            int fecha_limite = ((30 - libros_prestados.get(i).get_dia()) + dia + ((mes - libros_prestados.get(i).get_mes()) - 1) * 30) - 30;
            usuarios_registrados.get(j).set_multa(fecha_limite * 10000);
            usuarios_registrados.get(j).set_cantmultas();
            System.out.println("El libro fue devuelto con retraso. Excedió el límite máximo de 30 días prestados. Se le cobrará una multa de $10.000 por cada día de retraso. El valor total de su multa fue: " + usuarios_registrados.get(j).get_multa());
          }
        }
        System.out.println("El libro se ha devuelto el dia " + dia + " del mes " + mes + " del año " + año);
        System.out.println("El libro se ha devuelto con éxito");
        System.out.println("El libro ya no se encuentra prestado. El libro se encuentra disponible ahora.");
        libros_dispo.add(libros_prestados.get(i));
        libros_prestados.remove(i);
        libros_prestados.get(i).set_disponibilidad(true);
        usuarios_registrados.get(j).libros_prestados--;
        System.out.println("Los libros prestados por el usuario son: " + usuarios_registrados.get(j).get_librospres());
        }
       }
      }
     }
  if(usuario_encontrado == false){
    System.out.println("Usuario no encontrado en el sistema. Intente de nuevo");
    }
  if (libro_encontrado == false){
    System.out.println("Libro no encontrado en el sistema. Intente de nuevo");
    }
  }
  public void Consultar_multas(){
    Scanner input = new Scanner(System.in);
    System.out.println("Ingrese su nombre: ");
    String nombre = input.nextLine();
    System.out.println("Ingrese su numero de identificación: ");
    double id = input.nextDouble();
    boolean usuario_encontrado = false;
    for(int j = 0; j < usuarios_registrados.size(); j++){
       if(usuarios_registrados.get(j).get_nombre().equalsIgnoreCase(nombre) && usuarios_registrados.get(j).get_identificacion() == id){
      usuario_encontrado = true;
         if(usuarios_registrados.get(j).get_multa() > 0){
      System.out.println("El usuario " + usuarios_registrados.get(j).get_nombre() + " con numero de identificación " + usuarios_registrados.get(j).get_identificacion() + " tiene una multa de $" + usuarios_registrados.get(j).get_multa());
         }
         else if(usuarios_registrados.get(j).get_multa() == 0){
           System.out.println("El usuario " + usuarios_registrados.get(j).get_nombre() + " con numero de identificación " + usuarios_registrados.get(j).get_identificacion() + " no tiene multas, por lo tanto se encuentra a paz y salvo.");
         }
      }
    }
    if(usuario_encontrado == false){
      System.out.println("Usuario no encontrado en el sistema. Intente de nuevo");
    }
  }
  public void Pagar_multas(){
    System.out.println("A continuación consulte si tiene multas pendientes por pagar.");
    Consultar_multas();
    
  }
  public void Buscar_libros(){
    Scanner input = new Scanner(System.in);
    int opcion_bus = 0;
    do {
    System.out.println("¿Por cual item le gustaría filtrar su busqueda? \n" + "Ingrese el un número entre 1 y 5 que coresponda con su prefrenencia y si desea salirse y regresar al menú principal seleccione el número 6" + "1. Título del libro\n" + "2. Autor del libro\n" + "3. ISBN del libro" + "4. Categoría del libro" + "5. Disponibilidad del libro por categoría" + "6. Salir");
    opcion_bus = input.nextInt();
    if(opcion_bus == 1){
      System.out.println("Ingrese el titulo del libro que desea buscar: ");
      String titulo_1 = input.nextLine();
      boolean encontrado = false;
      for (int i = 0; i < catal_libros.size(); i++){
        if (titulo_1.equalsIgnoreCase(catal_libros.get(i).get_titulo())){
          encontrado = true;
          System.out.println("El libro se encuentra en nuestro catálogo");
          System.out.println("El nombre del autor es: " + catal_libros.get(i).get_autor());
          System.out.println("El ISBN es: " + catal_libros.get(i).get_ISBN());
          System.out.println("La categoría es: " + catal_libros.get(i).get_categoria());
          System.out.println("La disponibilidad es: " + catal_libros.get(i).get_disponibilidad());
          if (catal_libros.get(i).get_disponibilidad() == true){
            System.out.println("El libro se encuentra disponible para ser prestado");
          }
          else if (catal_libros.get(i).get_disponibilidad() == false){
            System.out.println("El libro no se encuentra disponible para ser prestado");
          }
        }
      }
      if (encontrado == false){
        System.out.println("El titulo del libro no se encuentra en nuestro catálogo");
        titulo_1 = input.nextLine();
      }
    }
    else if(opcion_bus == 2){
      System.out.println("Ingrese un autor del que desea buscar libros: ");
      String autor_1 = input.nextLine();
      boolean encontrado = false;
      for (int i = 0; i < catal_libros.size(); i++){
        System.out.println("Los libros que tenemos del autor seleccionado son: ");
        if (autor_1.equalsIgnoreCase(catal_libros.get(i).get_autor())){
          encontrado = true;
          System.out.println("El título del libro: " + catal_libros.get(i).get_autor());
          System.out.println("El ISBN es: " + catal_libros.get(i).get_ISBN());
          System.out.println("La categoría es: " + catal_libros.get(i).get_categoria());
          System.out.println("La disponibilidad es: " + catal_libros.get(i).get_disponibilidad());
          System.out.println();
          if (catal_libros.get(i).get_disponibilidad() == true){
            System.out.println("El libro se encuentra disponible para ser prestado");
          }
          else if (catal_libros.get(i).get_disponibilidad() == false){
            System.out.println("El libro no se encuentra disponible para ser prestado");
          }
        }
      }
      if (encontrado == false){
        System.out.println("No tenemos libros del autor seleccionado");
      }
    }
    else if(opcion_bus == 3){
      System.out.println("Ingrese el ISBN del libro que desea buscar (Sin caracteres especiales, solo numeros): ");
      double ISBN_1 = input.nextDouble();
      boolean encontrado = false;
      for (int i = 0; i < catal_libros.size(); i++){
        if (ISBN_1 == catal_libros.get(i).get_ISBN()){
          encontrado = true;
          System.out.println("El libro se encuentra en nuestro catálogo");
          System.out.println("El título del libro es: " + catal_libros.get(i).get_titulo());
          System.out.println("El nombre del autor es: " + catal_libros.get(i).get_autor());
          System.out.println("La categoría es: " + catal_libros.get(i).get_categoria());
          System.out.println("La disponibilidad es: " + catal_libros.get(i).get_disponibilidad());
          if (catal_libros.get(i).get_disponibilidad() == true){
            System.out.println("El libro se encuentra disponible para ser prestado");
          }
          else if (catal_libros.get(i).get_disponibilidad() == false){
            System.out.println("El libro no se encuentra disponible para ser prestado");
          }
        }
      }
      if (encontrado == false){
        System.out.println("El libro con el ISBN no ingresado no se encuentra en nuestro catálogo");
      }
    }
    else if (opcion_bus == 4){
      System.out.println("Ingrese una categoría de la que desea buscar libros: ");
      String categoria_1 = input.nextLine();
      boolean encontrado = false;
      for (int i = 0; i < catal_libros.size(); i++){
        System.out.println("Los libros que tenemos de la categoria seleccionada son: ");
        if (categoria_1.equalsIgnoreCase(catal_libros.get(i).get_categoria())){
          encontrado = true;
          System.out.println("El título del libro: " + catal_libros.get(i).get_titulo());
          System.out.println("El nombre del autor es: " + catal_libros.get(i).get_autor());
          System.out.println("El ISBN es: " + catal_libros.get(i).get_ISBN());
          System.out.println("La disponibilidad es: " + catal_libros.get(i).get_disponibilidad());
          System.out.println();
          if (catal_libros.get(i).get_disponibilidad() == true){
            System.out.println("El libro se encuentra disponible para ser prestado");
          }
          else if (catal_libros.get(i).get_disponibilidad() == false){
            System.out.println("El libro no se encuentra disponible para ser prestado");
          }
        }
      }
      if (encontrado == false){
        System.out.println("No tenemos libros de la categoría seleccionada");
      }
    }
    else if (opcion_bus == 5){
      System.out.println("Ingrese una categoría de la que desea buscar libros disponibles: ");
      String categoria_1 = input.nextLine();
      boolean encontrado = false;
      for (int i = 0; i < catal_libros.size(); i++){
        System.out.println("Los libros que tenemos disponibles de la categoria seleccionada son: ");
        if (categoria_1.equalsIgnoreCase(catal_libros.get(i).get_categoria()) && catal_libros.get(i).get_disponibilidad() == true ){
          encontrado = true;
          System.out.println("El título del libro: " + catal_libros.get(i).get_titulo());
          System.out.println("El nombre del autor es: " + catal_libros.get(i).get_autor());
          System.out.println("El ISBN es: " + catal_libros.get(i).get_ISBN());
          System.out.println("La disponibilidad es: " + catal_libros.get(i).get_disponibilidad());
          System.out.println();
        }
      }
      if (encontrado == false){
        boolean encontrado2 = false;
        System.out.println("No tenemos libros disponibles de la categoría seleccionada.");
        for (int i = 0; i < catal_libros.size(); i++){
          System.out.println("Los libros que tenemos prestados de la categoria seleccionada son: ");
          if (categoria_1.equalsIgnoreCase(catal_libros.get(i).get_categoria()) && catal_libros.get(i).get_disponibilidad() == true ){
            encontrado2 = true;
            System.out.println("El título del libro: " + catal_libros.get(i).get_titulo());
            System.out.println("El nombre del autor es: " + catal_libros.get(i).get_autor());
            System.out.println("El ISBN es: " + catal_libros.get(i).get_ISBN());
            System.out.println("La disponibilidad es: " + catal_libros.get(i).get_disponibilidad());
            System.out.println();
          }
        }
        if (encontrado2 == false){
          System.out.println("No tenemos libros disponibles de esa categoria.");
        }
      }
    }
    else if(opcion_bus == 6){
      System.out.println("Muchas gracias por confiar en nuestros servicios");
      break;
    }
      else {
        System.out.println("Error. Ingrese una opción válida");
      }
  } while(opcion_bus > 0 && opcion_bus < 7);
  }
}