public class Usuarios {
  private String nombre;
  public double identificacion;
  public int libros_prestados;
  private double multa;
  private int cantidad_multas;
  
  public Usuarios(){
    
  }
  public Usuarios(String nombre, double identificacion){
    this.nombre = nombre;
    this.identificacion = identificacion;
    this.multa = 0.0;
    this.cantidad_multas = 0;
    this.libros_prestados = 0;
  }
  public void set_nombre(String nombre){
    this.nombre = nombre;
  }
  public String get_nombre(){
    return nombre;
  }
  public void set_identificacion(double id){
    this.identificacion = id;
  }
  public double get_identificacion(){
    return identificacion;
  }
  public void set_librospres(int libros_prestados){
    this.libros_prestados = libros_prestados;
  }
  public int get_librospres(){
    return libros_prestados;
  }
  public void set_multa(double multa){
    this.multa = multa;
  }
  public double get_multa(){
    return multa;
  }
  public void set_cantmultas(){
    this.cantidad_multas++;
  }
  public int get_cantmultas(){
    return cantidad_multas;
  }
}