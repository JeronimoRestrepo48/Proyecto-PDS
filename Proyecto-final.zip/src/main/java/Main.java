import java.util.Scanner;
public class Main {
  public static void main(String[] args){
    Scanner input = new Scanner(System.in);
    int opcion = 0;
    do {
      Libros libro = new Libros();
      System.out.println("Bienvenido a la Biblioteca\n" + "Seleccione la acción que desea hacer escribiendo el número correspondiente\n" + "1. Agregar Libro\n" + "2. Eliminar Libro\n" + "3. Ver catálogo de libros\n" + "4. Prestar Libro\n" + "5. Devolver Libro\n" +  "6. Ver libros disponibles\n" + "7. Ver libros prestados\n" + "8. Bucar o filtrar libros\n" + "9. Ver usuarios registrados\n" + "10. Consultar multas\n" + "11. Salir");
      opcion = input.nextInt();
      if(opcion == 1){
        libro.agregar_libros();
      }
      else if (opcion == 2){
        libro.eliminar_libros();
      }
      else if (opcion == 3){
        libro.get_catalogo();
      }
      else if (opcion == 4){
        libro.prestar_libros();
      }
      else if (opcion == 5){
        libro.devolver_libros();
      }
      else if (opcion == 6){
        libro.mostrar_librosdisp();
      }
      else if (opcion == 7){
        libro.mostrar_librospres();
      }
      else if (opcion == 8){
        libro.Buscar_libros();
      }
      else if (opcion == 9){
        libro.mostrar_usuariosregistrados();
      }
      else if (opcion == 10){
        libro.Consultar_multas();
      }
      else if (opcion == 11){
        System.out.println("Muchas gracias por confiar en nuestros servicios. Esperamos que vuelva pronto.");
      }
      else {
        System.out.println("Error. La opción que ha ingresado es inválida. Intente de nuevo por favor");
      }
    } while (opcion > 0 && opcion < 10);
  }
}